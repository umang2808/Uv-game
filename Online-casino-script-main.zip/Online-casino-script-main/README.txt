Crypto Casino
-------------

Please open documentation/index.html